<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="panel panel-heading">
                <div class="row">
                    Agregar producto
                    <a href="/products" class="btn btn-primary btn-sm">Volver a productos</a>
                </div>
            </div>

            <div class="panel-body">
                <?php if( session('mensaje') ): ?>
                    <div class="alert alert-success"><?php echo e(session('mensaje')); ?></div>
                <?php endif; ?>

                <form method="POST" action="/products">
                    <?php echo e(csrf_field()); ?>


                    <input
                      type="text"
                      name="code"
                      placeholder="Código"
                      class="form-control mb-2"
                      required
                    />

                    <input
                      type="text"
                      name="name"
                      placeholder="Nombre"
                      class="form-control mb-2"
                      required
                    />

                    <input
                      type="text"
                      name="description"
                      placeholder="Descripcion"
                      class="form-control mb-2"
                      required
                    />

                    <input
                      type="text"
                      name="weight"
                      placeholder="Peso"
                      class="form-control mb-2"
                      required
                    />

                    <input
                      type="text"
                      name="state"
                      placeholder="Estado"
                      class="form-control mb-2"
                      required
                    />

                    <button class="btn btn-primary btn-block" type="submit">Agregar</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>