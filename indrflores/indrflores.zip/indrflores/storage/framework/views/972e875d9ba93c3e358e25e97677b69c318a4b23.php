<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <div class="col-md-8 col-md-offset-2">
      <div class="panel panel-default">
        <div class="panel-heading">
          Nueva venta
          <a href="/sales" class="btn btn-primary btn-sm">Volver a ventas</a>

        </div>

        <div class="panel-body">
        <?php if( session('message') ): ?>
          <div class="alert alert-success"><?php echo e(session('message')); ?></div>
          <?php elseif( session('error') ): ?>
          <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
          <?php endif; ?>

          <form method="POST" action="/sales">
            <?php echo e(csrf_field()); ?>


            <input id="product_id" name="product_id" type="hidden" />

            <div class="form-group">
              <select id="product" name="product" class="form-control">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option 
                    id=<?php echo e($product->id); ?> 
                    value=<?php echo e($product->id); ?>

                  ><?php echo e($product->code); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <input id="description" type="text" name="description" 
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
              <?php if($loop->first and $product != null): ?>
                value="<?php echo e($product->description); ?>"
                <?php else: ?>
                value=""
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            placeholder="Descripción del código"
            class="form-control mb-2"
            readonly
            />

            <input id="weight" type="number" name="weight" step="0.01" placeholder="Ingrese el peso del producto" class="form-control mb-2" required />

            <input id="value" type="number" name="value" step="0.01" placeholder="Valor en dólares del producto" class="form-control mb-2" readonly />

            <input id="stock" type="number" name="stock"
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
              <?php if($loop->first and $product != null): ?>
                value="<?php echo e($product->stock); ?>"
                <?php else: ?>
                value=""
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            placeholder="En almacén" 
            class="form-control mb-2" 
            readonly 
            />

            <input type="datetime-local" name="sale_date" value="<?php echo e(date('Y-m-d\TH:i')); ?>" min="2020-01-01T00:00" class="form-control mb-2" readonly />

            <button id="submit" class="btn btn-primary btn-block" type="submit">Agregar</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="<?php echo e(asset('js/dropdown.js')); ?>"></script>
  <script src="<?php echo e(asset('js/test.js')); ?>"></script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>