<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8 col-md-offset-2">
      <div class="panel panel-default">
        <div class="panel-heading">
          Actualizar producto

          <a href="/products" class="btn btn-primary btn-sm">Volver a productos</a>
        </div>

        <div class="panel-body">
          <?php if( session('message') ): ?>
          <div class="alert alert-success"><?php echo e(session('message')); ?></div>
          <?php endif; ?>

          <form method="POST" action="<?php echo e(action('ProductController@update', $product->id)); ?>">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>


            <input id="code" type="text" name="code" placeholder="Código" value="<?php echo e($product->code); ?>" class="form-control mb-2" onkeyup="javascript:this.value=this.value.toUpperCase();" required />

            <input id="description" type="text" name="description" placeholder="Descripcion" value="<?php echo e($product->description); ?>" class="form-control mb-2" onkeyup="javascript:this.value=this.value.toUpperCase();" required />

            <input id="value" type="number" step="0.01" name="value" placeholder="Valor" value="<?php echo e($product->value); ?>" class="form-control mb-2" required />

            <input id="stock" type="number" step="0.01" name="stock" placeholder="En almacén" value="<?php echo e($product->stock); ?>" class="form-control mb-2" required />

            <button class="btn btn-warning btn-block" type="submit">Editar</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>