<?php $__env->startSection('content'); ?>

<div id="test">
    <h1>press me!</h1>
</div>

<div class="form-group">
    <select id="sel-test" name="test" class="form-control">
        <option id="1">primero</option>
        <option id="2">segundo</option>
        <option id="3">trcero</option>
    </select>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="<?php echo e(asset('js/test.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>