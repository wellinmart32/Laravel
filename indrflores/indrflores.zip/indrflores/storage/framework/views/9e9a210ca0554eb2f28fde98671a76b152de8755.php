<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8 col-md-offset-2">
      <div class="panel panel-default">
        <div class="panel-heading">
          Actualizar venta

          <a href="/sales" class="btn btn-primary btn-sm">Volver a ventas</a>
        </div>

        <div class="panel-body">
          <?php if( session('message') ): ?>
          <div class="alert alert-success"><?php echo e(session('message')); ?></div>
          <?php endif; ?>

          <form method="POST" action="<?php echo e(action('SaleController@update', $sale->id)); ?>">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>


            <input id="product_id" name="product_id" type="hidden" />

            <div class="form-group">
              <select id="product" name="product" class="form-control">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option 
                    id=<?php echo e($product->id); ?> 
                    value=<?php echo e($product->id); ?>

                    <?php if($sale->product_id == $product->id): ?> 
                      selected="selected"
                    <?php endif; ?>
                  ><?php echo e($product->code); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <input id="description" type="text" name="description" placeholder="Descripción" value="<?php echo e($productSelected->description); ?>" class="form-control mb-2" readonly />

            <input id="weight" type="number" step="0.01" name="weight" placeholder="Peso" value="<?php echo e($sale->weight); ?>" class="form-control mb-2" required />

            <input id="value" type="number" step="0.01" name="value" placeholder="Valor" value="<?php echo e($sale->weight*$productSelected->value); ?>" class="form-control mb-2" readonly />

            <input id="stock" type="number" step="0.01" name="stock" placeholder="En almacén" value="<?php echo e($productSelected->stock); ?>" class="form-control mb-2" readonly />

            <input type="date" name="sale_date" value="2022-02-07" min="2022-01-01" class="form-control mb-2" readonly />

            <button class="btn btn-warning btn-block" type="submit">Editar</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="<?php echo e(asset('js/dropdown.js')); ?>"></script>
  <script src="<?php echo e(asset('js/test.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>