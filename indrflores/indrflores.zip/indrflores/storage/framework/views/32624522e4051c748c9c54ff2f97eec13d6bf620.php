

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Buscar producto

                    <a href="/products" class="btn btn-primary btn-sm">Volver a productos</a>
                </div>

                <div class="panel-body">
                    <?php if( session('mensaje') ): ?>
                        <div class="alert alert-success"><?php echo e(session('mensaje')); ?></div>
                    <?php endif; ?>

                    <form class="form-horizontal" method="POST" action="<?php echo e(action('ProductController@search')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('POST')); ?>


                        <div class="row">
                            <div class="col-md-4">
                                <p>Fecha inicio</p>
                                <input type="date"
                                    name="st_dt"
                                    min="2019-12-31"
                                    value="2019-12-31"
                                    class="form-control mb-2"
                                />

                                <p>Fecha fin</p>
                                <input type="date"
                                    name="fn_dt"
                                    min="2020-01-01"
                                    value="<?php echo e(date('Y-m-d')); ?>"
                                    class="form-control mb-2"
                                />
                            </div>
                        </div>

                        <br />
                            
                        <button class="btn btn-primary btn-block" type="submit">Buscar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>