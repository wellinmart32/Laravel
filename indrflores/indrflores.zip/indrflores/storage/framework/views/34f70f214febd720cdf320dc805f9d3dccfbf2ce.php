<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-8 col-md-offset-2">
      <div class="panel panel-default">
        <div class="panel-heading">
          Eliminar Venta

          <a href="/sales" class="btn btn-primary btn-sm">Volver a ventas</a>
        </div>

        <div class="panel-body">
          <?php if( session('mensaje') ): ?>
          <div class="alert alert-success"><?php echo e(session('mensaje')); ?></div>
          <?php endif; ?>

          <form method="POST" action="<?php echo e(action('SaleController@destroy', $sale->id)); ?>">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('DELETE')); ?>


            <input id="code" type="text" name="code" placeholder="Código" value="<?php echo e($productSelected->code); ?>" class="form-control mb-2" disabled="disabled" />

            <input id="description" type="text" name="description" placeholder="Descripcion" value="<?php echo e($productSelected->description); ?>" class="form-control mb-2" disabled="disabled" />

            <input id="weight" type="number" name="weight" placeholder="Peso" value="<?php echo e($sale->weight); ?>" class="form-control mb-2" disabled="disabled" />

            <input id="value" type="number" name="value" placeholder="Valor" value="<?php echo e($sale->weight*$productSelected->value); ?>" class="form-control mb-2" disabled="disabled" />

            <button class="btn btn-danger btn-block" type="submit">Eliminar</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>