/*
$('#test').on( "click", function()
{
  alert("Hola Mundo con jQuery!");
});
*/
$(document).ready(function()
{
  $('#sel-test').on('change', function()
  {
    alert("Hola Mundo con jQuery!");
  });
});
