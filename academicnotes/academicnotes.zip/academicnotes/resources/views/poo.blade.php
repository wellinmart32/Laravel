<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased">
        <h1>Los diagramas de flujo, Tipos de diagramas de flujo y su Simbología, estándares</h1>
        <h2>
            Los diagramas de flujo son una representación gráfica del algoritmo, nos permite observa, el flujo del proceso, a través de la representación gráfica de los pasos del algortimo, es la herramienta más utilizadas de un programador o ingeniero en sistemas para diseñar algoritmos (Joyanes Aguilar, 2019):
            A continuación, vemos la equivalencia de un algortimo, y su representación en Flujograma.
        </h2>
    </body>
</html>
